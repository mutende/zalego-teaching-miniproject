</div>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Zalego Course Application</b>
    </div>
    <strong>Copyright &copy; 2019 <a href="mailto:denniskiprotich0@gmail.com">Zalego</a>.</strong> All rights
    reserved.
  </footer>