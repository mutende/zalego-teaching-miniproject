<?php
 $conn = mysqli_connect("localhost","mutende","m2825","zalego");
 if(mysqli_connect_errno())
  {
   echo "Error: ".mysqli_connect_error();
  }
?>
